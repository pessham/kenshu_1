# 第2回研修 宿題課題【Bさん専用】

---

## 📋 課題の概要

Aさん（Python/VS Codeチーム）が、**「製品検査AIシステム」の正式な仕様** を作成してくれました。

配布されている4つのJSONファイルは、**Aさんが設計した「AIからこういう形式でデータが来る」という仕様書** です。

この仕様をもとに、**Visual Studio × VB.NET でどんな処理を作る必要があるか** を考えてください。

---

## 📁 Aさんが作成した仕様書ファイル一覧

| ファイル名 | 内容 |
|-----------|------|
| `01_onnx_output_sample.json` | ONNXが出力する推論結果のサンプル |
| `02_workflow_definition.json` | 処理フローの定義（台本） |
| `03_llm_prompt_template.json` | LLMへの指示テンプレート |
| `04_final_output_schema.json` | 最終出力のJSON形式 |

---

## 🎯 課題1：JSONファイルを読み解く（20分）

各JSONファイルを開いて、以下の点を確認してください。

### 確認ポイント

1. **01_onnx_output_sample.json**
   - ONNXが返すデータにはどんな情報が含まれていますか？
   - `score` が 0.94 とは、何を意味していますか？
   - `bounding_box` は何のためにありますか？

2. **02_workflow_definition.json**
   - 処理は全部で何ステップありますか？
   - エラーが起きたとき、どう対処すると書いてありますか？

3. **04_final_output_schema.json**
   - 最終的に出力されるJSONには、入力時になかった情報が追加されています。
   - どんな情報が追加されていますか？（例：`risk_level` など）

---

## 🎯 課題2：VB.NETでの実装イメージを考える（30分）

紙やメモ帳に、以下の内容を書き出してください。

### 書くこと

1. **クラス設計（ざっくりでOK）**
   
   以下のようなクラスを作るとしたら、どんなプロパティが必要ですか？
   
   ```vb
   ' 例：ONNXの結果を受け取るクラス
   Public Class OnnxResult
       Public Property ImageId As String
       Public Property Label As String
       Public Property Score As Double
       ' ... 他に何が必要？
   End Class
   ```

2. **処理の流れ（フローチャートまたは箇条書き）**
   
   ```
   ① JSONファイルを読み込む
   ② 1件ずつループで処理
   ③ risk_level を計算（scoreとlabelから）
   ④ LLMを呼び出して説明文を取得
   ⑤ 最終JSONを組み立てる
   ⑥ DBに保存 & 必要なら通知
   ```

3. **分からないこと・質問したいこと**
   
   - 「ここはどうやって実装するんだろう？」
   - 「この部分、研修で詳しく聞きたい」
   
   などがあればメモしておいてください。第3回で解説します。

---

## 🎯 課題3（発展）：Copilotでコメント駆動開発を試す

余裕がある方は、Part1で学んだ「コメント駆動開発」を使って、
以下のメソッドの **コメントだけ** 書いてみてください。

```vb
' ここにコメントを書く
' - 何をするメソッドか
' - 入力は何か
' - エラー条件
' - 戻り値
Public Function CalculateRiskLevel(...) As String
    ' Copilotがここにコードを提案してくれる
End Function
```

**書いてほしいメソッド例：**

- `CalculateRiskLevel` ：scoreとlabelからrisk_levelを判定
- `LoadOnnxResults` ：JSONファイルを読み込んでリストで返す
- `SendNotification` ：risk_levelがhighのときだけメール送信

---

## ⏰ 提出について

- 次回研修（第3回）の冒頭で、課題2の内容を簡単に共有していただきます
- 完璧に書く必要はありません。「考えてみた」ことが大事です
- 質問事項は大歓迎です。第3回で一緒に解決しましょう

---

## 💡 ヒント

- JSONの読み書きには `System.Text.Json` または `Newtonsoft.Json` を使います
- VB.NETでのJSON操作に不安がある方は、Copilotに聞いてみましょう
  
  ```
  /explain VB.NETでJSONファイルを読み込んでオブジェクトに変換する方法を教えて
  ```

- 第3回では、実際にSemantic Kernel（.NET版）を使った実装に入ります

---

## 🔗 次回（第3回）の予告

- RAG（検索拡張生成）の仕組み
- Semantic Kernel for .NET の基本
- 今回の課題を実際にコードに落としていく

---

**質問があればいつでもどうぞ！**
